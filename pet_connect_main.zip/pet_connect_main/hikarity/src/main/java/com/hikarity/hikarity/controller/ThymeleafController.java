package com.hikarity.hikarity.controller;

import java.util.HashMap; // 추가된 import 문
import java.util.List;
import java.util.Map;
import java.util.Arrays;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.hikarity.hikarity.DTO.Adoption;
import com.hikarity.hikarity.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;



@Slf4j
@Controller
public class ThymeleafController {
    
    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String getMainPage(Model model) {
        return "main"; // main.html 뷰를 반환
    }

    @GetMapping("/api/animals")
@ResponseBody
public Map<String, Object> getAnimals(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size,
        @RequestParam(required = false) String category,
        @RequestParam(required = false) String search) { // 검색어 추가
        
                Map<String, Object> response = new HashMap<>();
            try {


                List<Map<String, Object>> allAnimals = userService.getAll();

                // 카테고리 필터링

                    if (category != null && !category.isEmpty()) {
                        String[] categories = category.split(","); // 여러 카테고리 지원
                        List<String> categoryList = Arrays.asList(categories); // 카테고리 리스트
            
                        // 필터링 로직
                        allAnimals = allAnimals.stream()
                            .filter(animal -> {
                                String speciesName = animal.get("SPECIES_NM") != null ? animal.get("SPECIES_NM").toString().trim() : ""; // null 체크
                                return categoryList.stream().anyMatch(cat -> speciesName.contains(cat.trim())); // 대소문자 무시
                            })
                            .collect(Collectors.toList());
                    }


        // 검색어 필터링
        if (search != null && !search.isEmpty()) {
            allAnimals = allAnimals.stream()
                .filter(animal -> animal.get("SPECIES_NM").toString().toLowerCase().contains(search.toLowerCase()))
                .collect(Collectors.toList());
        }

        int totalItems = allAnimals.size();
        int totalPages = (int) Math.ceil((double) totalItems / size);

        int start = page * size;
        int end = Math.min(start + size, totalItems);
        
        List<Map<String, Object>> paginatedAnimals = allAnimals.subList(start, end);

        response.put("animals", paginatedAnimals);
        response.put("totalPages", totalPages);
        response.put("currentPage", page);
        } catch (Exception e) {
            log.error("Error fetching animals: ", e);
            response.put("error", "동물 정보를 가져오는 데 문제가 발생했습니다.");
        }
    return response;
    }


    @GetMapping("/animal/{Idx}")
    public String getDetailedAnimal(@PathVariable("Idx") String Idx, Model model) {
        Map<String, Object> animal = userService.getDetailedAnimal(Idx);  // Fetch the details of the animal by ID
        
        model.addAttribute("animal", animal);
        return "detail";
    }

    @GetMapping("/adopt/{Idx}")
    public String getMethodName(@PathVariable("Idx") String Idx, Model model) {

        model.addAttribute("Idx", Idx);
        return "adopt";
    }
    


    @PostMapping("/adopt_ok")
    public String adopt(@ModelAttribute Adoption dto, HttpServletRequest request) throws Exception { 
        userService.insertAdoption(dto);
        
        return "redirect:/";
    }
    
}
